<?php

namespace Mlangeni\Machinjiri\Core\Routing\Contracts;

use Mlangeni\Machinjiri\Core\Http\HttpRequest;
use Mlangeni\Machinjiri\Core\Http\HttpResponse;

interface Middleware
{
    public function process(HttpRequest $request, HttpResponse $response, callable $next): HttpResponse;
}