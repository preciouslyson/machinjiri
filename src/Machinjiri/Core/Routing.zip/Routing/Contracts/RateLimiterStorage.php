<?php

namespace Mlangeni\Machinjiri\Core\Routing\Contracts;

interface RateLimiterStorage
{
    /**
     * Increment the counter for the given key and return the current count.
     * The storage should expire the key after $ttl seconds.
     */
    public function increment(string $key, int $ttl): int;

    /**
     * Get the current count for the key without incrementing.
     */
    public function get(string $key): int;

    /**
     * Reset the counter for the key.
     */
    public function reset(string $key): void;
}