<?php

namespace Mlangeni\Machinjiri\Core\Routing\Contracts;

interface RouteHandlerResolver
{
    /**
     * Resolve the handler to a callable that accepts (HttpRequest, HttpResponse, array $params).
     */
    public function resolve($handler): callable;
}