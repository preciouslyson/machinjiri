<?php

namespace Mlangeni\Machinjiri\Core\Routing;

use Mlangeni\Machinjiri\Core\Http\HttpRequest;
use Mlangeni\Machinjiri\Core\Http\HttpResponse;

class CorsManager
{
    public function applyHeaders(HttpResponse $response, array $config): void
    {
        $config = array_merge([
            'allowed_origins' => ['*'],
            'allowed_methods' => ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
            'allowed_headers' => ['*'],
            'max_age' => 86400,
        ], $config);
        // In real code, check Origin header and only set if allowed
        $response->setHeader('Access-Control-Allow-Origin', '*')
                 ->setHeader('Access-Control-Allow-Methods', implode(', ', $config['allowed_methods']))
                 ->setHeader('Access-Control-Allow-Headers', implode(', ', $config['allowed_headers']))
                 ->setHeader('Access-Control-Max-Age', $config['max_age']);
    }

    public function handlePreflight(HttpRequest $request, HttpResponse $response, array $config): bool
    {
        if ($request->getMethod() === 'OPTIONS') {
            $this->applyHeaders($response, $config);
            $response->setStatusCode(204)->send();
            return true;
        }
        return false;
    }
}