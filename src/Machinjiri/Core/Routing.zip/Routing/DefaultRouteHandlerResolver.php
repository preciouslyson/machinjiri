<?php

namespace Mlangeni\Machinjiri\Core\Routing;

use Mlangeni\Machinjiri\Core\Exceptions\MachinjiriException;
use Mlangeni\Machinjiri\Core\Routing\Contracts\RouteHandlerResolver as ResolverContract;

class DefaultRouteHandlerResolver implements ResolverContract
{
    public function resolve($handler): callable
    {
        if (is_callable($handler)) {
            return $handler;
        }
        if (is_string($handler) && str_contains($handler, '@')) {
            [$class, $method] = explode('@', $handler);
            $class = 'Mlangeni\\Machinjiri\\App\\Controllers\\' . $class;
            return fn($req, $res, $params) => (new $class())->{$method}($req, $res, ...array_values($params));
        }
        if (is_array($handler) && count($handler) === 2) {
            [$class, $method] = $handler;
            return fn($req, $res, $params) => (is_string($class) ? new $class() : $class)->{$method}($req, $res, ...array_values($params));
        }
        throw new MachinjiriException('Invalid route handler');
    }
}