<?php

namespace Mlangeni\Machinjiri\Core\Routing;

use Mlangeni\Machinjiri\Core\Routing\Contracts\RateLimiterStorage;

class InMemoryRateLimiterStorage implements RateLimiterStorage
{
    protected array $storage = [];

    public function increment(string $key, int $ttl): int
    {
        $this->storage[$key] = ($this->storage[$key] ?? 0) + 1;
        return $this->storage[$key];
    }

    public function get(string $key): int
    {
        return $this->storage[$key] ?? 0;
    }

    public function reset(string $key): void
    {
        unset($this->storage[$key]);
    }
}