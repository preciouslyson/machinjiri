<?php

namespace Mlangeni\Machinjiri\Core\Routing;

use Mlangeni\Machinjiri\Core\Http\HttpRequest;
use Mlangeni\Machinjiri\Core\Http\HttpResponse;
use Mlangeni\Machinjiri\Core\Routing\Contracts\Middleware;

class MiddlewareDispatcher
{
    protected array $globalMiddleware = [];

    public function addGlobalMiddleware(Middleware $middleware): void
    {
        $this->globalMiddleware[] = $middleware;
    }

    public function dispatch(HttpRequest $request, HttpResponse $response, array $routeMiddleware, callable $finalHandler): HttpResponse
    {
        $middlewares = array_merge($this->globalMiddleware, $routeMiddleware);
        $next = $finalHandler;
        for ($i = count($middlewares) - 1; $i >= 0; $i--) {
            $middleware = $middlewares[$i];
            $next = function (HttpRequest $req, HttpResponse $res, array $params) use ($middleware, $next) {
                return $middleware->process($req, $res, function ($req, $res) use ($next, $params) {
                    return $next($req, $res, $params);
                });
            };
        }
        return $next($request, $response, []);
    }
}