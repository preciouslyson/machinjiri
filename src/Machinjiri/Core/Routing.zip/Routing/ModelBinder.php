<?php

namespace Mlangeni\Machinjiri\Core\Routing;

use Mlangeni\Machinjiri\Core\Exceptions\MachinjiriException;

class ModelBinder
{
    public function bind(array $params, array $bindings): array
    {
        foreach ($bindings as $paramName => $modelClass) {
            if (isset($params[$paramName])) {
                $model = $modelClass::find($params[$paramName]);
                if (!$model) {
                    throw new MachinjiriException("{$modelClass} not found for id {$params[$paramName]}");
                }
                $params[$paramName] = $model;
            }
        }
        return $params;
    }
}