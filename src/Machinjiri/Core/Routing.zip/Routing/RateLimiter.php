<?php

namespace Mlangeni\Machinjiri\Core\Routing;

use Mlangeni\Machinjiri\Core\Routing\Contracts\RateLimiterStorage;
use Mlangeni\Machinjiri\Core\Http\HttpRequest;

class RateLimiter
{
    protected array $limiters = [];

    public function __construct(protected RateLimiterStorage $storage) {}

    public function define(string $name, int $maxRequests, int $periodSeconds): void
    {
        $this->limiters[$name] = ['max' => $maxRequests, 'period' => $periodSeconds];
    }

    public function attempt(string $name, HttpRequest $request): bool
    {
        if (!isset($this->limiters[$name])) {
            return true;
        }
        $limiter = $this->limiters[$name];
        $key = $this->getKey($name, $request);
        $current = $this->storage->increment($key, $limiter['period']);
        return $current <= $limiter['max'];
    }

    public function getRemainingAttempts(string $name, HttpRequest $request): int
    {
        $limiter = $this->limiters[$name];
        $key = $this->getKey($name, $request);
        $current = $this->storage->get($key);
        return max(0, $limiter['max'] - $current);
    }

    protected function getKey(string $name, HttpRequest $request): string
    {
        $ip = $request->getServerParam('REMOTE_ADDR', 'unknown');
        return "rate_limit:{$name}:{$ip}";
    }
}