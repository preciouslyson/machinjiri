<?php

namespace Mlangeni\Machinjiri\Core\Routing\RateLimiter;

use Mlangeni\Machinjiri\Core\Artisans\Caching\CacheManager;
use Mlangeni\Machinjiri\Core\Artisans\Caching\Stores\RedisStore;
use Mlangeni\Machinjiri\Core\Routing\Contracts\RateLimiterStorage;

class CacheRateLimiterStorage implements RateLimiterStorage
{
    protected CacheManager $cache;
    protected string $prefix;

    public function __construct(CacheManager $cache, string $prefix = 'rate_limiter:')
    {
        $this->cache = $cache;
        $this->prefix = $prefix;
    }

    /**
     * {@inheritdoc}
     */
    public function increment(string $key, int $ttl): int
    {
        $fullKey = $this->prefix . $key;
        $store = $this->cache->store();

        // Use Redis Lua script for true atomic increment + expire
        if ($store instanceof RedisStore) {
            return $this->redisIncrement($store, $fullKey, $ttl);
        }

        // Fallback for non‑atomic stores (file, array) – optimistic locking
        return $this->safeIncrement($store, $fullKey, $ttl);
    }

    /**
     * {@inheritdoc}
     */
    public function get(string $key): int
    {
        $fullKey = $this->prefix . $key;
        return (int) $this->cache->get($fullKey, 0);
    }

    /**
     * {@inheritdoc}
     */
    public function reset(string $key): void
    {
        $fullKey = $this->prefix . $key;
        $this->cache->delete($fullKey);
    }

    /**
     * Atomic increment + expire using Redis Lua script.
     */
    protected function redisIncrement(RedisStore $store, string $key, int $ttl): int
    {
        $lua = <<<'LUA'
            local current = redis.call('INCR', KEYS[1])
            if current == 1 then
                redis.call('EXPIRE', KEYS[1], ARGV[1])
            end
            return current
LUA;

        $result = $store->getClient()->eval($lua, 1, $key, $ttl);
        return (int) $result;
    }

    /**
     * Safe increment for stores without atomic operations.
     * Uses a short lock to minimise race conditions.
     */
    protected function safeIncrement($store, string $key, int $ttl): int
    {
        $lockKey = $key . ':lock';
        $maxRetries = 5;

        for ($attempt = 1; $attempt <= $maxRetries; $attempt++) {
            // Try to acquire a lock (expires after 1 second)
            $locked = $store->add($lockKey, 1, 1);
            if ($locked) {
                try {
                    $current = (int) $store->get($key, 0);
                    $new = $current + 1;
                    $store->set($key, $new, $ttl);
                    return $new;
                } finally {
                    $store->delete($lockKey);
                }
            }
            // Lock collision – wait a bit and retry
            usleep(20000); // 20ms
        }

        // Fallback: force increment without lock (may overcount, but rate limiting still works)
        $current = (int) $store->get($key, 0);
        $new = $current + 1;
        $store->set($key, $new, $ttl);
        return $new;
    }
}