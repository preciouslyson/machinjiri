<?php

namespace Mlangeni\Machinjiri\Core\Routing;

class Route
{
    public function __construct(
        public readonly array $methods,
        public readonly string $pattern,
        public readonly mixed $handler,
        public readonly ?string $name = null,
        public readonly array $middleware = [],
        public readonly ?array $cors = null,
        public readonly ?string $rateLimiter = null,
        public readonly bool $ajaxOnly = false,
        public readonly bool $noAjax = false,
        public readonly array $constraints = [],
        public readonly array $bindings = []  // ['param' => ModelClass::class]
    ) {}

    public function compileRegex(array $constraints = []): string
    {
        $pattern = $this->pattern;
        $constraints = array_merge($this->constraints, $constraints);
        $regex = preg_replace_callback('/\{([a-zA-Z_][a-zA-Z0-9_]*)\}/', function ($m) use ($constraints) {
            $name = $m[1];
            $regex = $constraints[$name] ?? '[^/]+';
            return '(?P<' . $name . '>' . $regex . ')';
        }, $pattern);
        return '#^' . preg_quote($regex, '#') . '$#i';
    }
}