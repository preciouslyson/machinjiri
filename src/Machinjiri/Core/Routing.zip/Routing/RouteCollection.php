<?php

namespace Mlangeni\Machinjiri\Core\Routing;

class RouteCollection
{
    protected array $routes = [];
    protected array $namedRoutes = [];

    public function add(Route $route): void
    {
        $this->routes[] = $route;
        if ($route->name) {
            $this->namedRoutes[$route->name] = $route;
        }
    }

    /** @return Route[] */
    public function all(): array
    {
        return $this->routes;
    }

    public function getByName(string $name): ?Route
    {
        return $this->namedRoutes[$name] ?? null;
    }
}