<?php

namespace Mlangeni\Machinjiri\Core\Routing;

use Mlangeni\Machinjiri\Core\Http\HttpRequest;

class RouteMatcher
{
    public function __construct(
        protected RouteCollection $collection,
        protected string $basePath = ''
    ) {}

    public function match(HttpRequest $request): ?array
    {
        $method = $request->getMethod();
        $uri = $this->normalizeUri($request->getUri());

        foreach ($this->collection->all() as $route) {
            if (!in_array($method, $route->methods) && !in_array('ANY', $route->methods)) {
                continue;
            }
            if ($route->ajaxOnly && !$request->isAjax()) {
                continue;
            }
            if ($route->noAjax && $request->isAjax()) {
                continue;
            }

            $regex = $route->compileRegex();
            if (preg_match($regex, $uri, $matches)) {
                $params = array_filter($matches, 'is_string', ARRAY_FILTER_USE_KEY);
                return ['route' => $route, 'params' => $params];
            }
        }
        return null;
    }

    protected function normalizeUri(string $uri): string
    {
        $uri = parse_url($uri, PHP_URL_PATH);
        if ($this->basePath && strpos($uri, $this->basePath) === 0) {
            $uri = substr($uri, strlen($this->basePath));
        }
        return rtrim($uri, '/') ?: '/';
    }
}