<?php

namespace Mlangeni\Machinjiri\Core\Routing;

use Mlangeni\Machinjiri\Core\Container;
use Mlangeni\Machinjiri\Core\Http\HttpRequest;
use Mlangeni\Machinjiri\Core\Http\HttpResponse;
use Mlangeni\Machinjiri\Core\Artisans\Caching\CacheManager;
use Mlangeni\Machinjiri\Core\Routing\RateLimiter\CacheRateLimiterStorage;
use Mlangeni\Machinjiri\Core\Exceptions\MachinjiriException;

class Router
{
    protected RouteCollection $collection;
    protected RouteMatcher $matcher;
    protected UrlGenerator $urlGenerator;
    protected MiddlewareDispatcher $middlewareDispatcher;
    protected RateLimiter $rateLimiter;
    protected CorsManager $corsManager;
    protected ModelBinder $modelBinder;
    protected DefaultRouteHandlerResolver $handlerResolver;
    protected HttpRequest $request;
    protected HttpResponse $response;
    protected string $basePath;
    protected array $groupStack = [];

    public function __construct(
        ?string $basePath = null,
        ?HttpRequest $request = null,
        ?HttpResponse $response = null,
        ?CacheManager $cacheManager = null
    ) {
        $this->basePath = $basePath ?? $this->detectBasePath();
        $this->request = $request ?? HttpRequest::createFromGlobals();
        $this->response = $response ?? new HttpResponse();
        $this->collection = new RouteCollection();
        $this->matcher = new RouteMatcher($this->collection, $this->basePath);
        $this->urlGenerator = new UrlGenerator($this->collection, $this->basePath);
        $this->middlewareDispatcher = new MiddlewareDispatcher();

        $storage = $cacheManager
            ? new CacheRateLimiterStorage($cacheManager)
            : new InMemoryRateLimiterStorage();

        $this->rateLimiter = new RateLimiter($storage);
        $this->corsManager = new CorsManager();
        $this->modelBinder = new ModelBinder();
        $this->handlerResolver = new DefaultRouteHandlerResolver();
    }

    // ---------- HTTP Method Shortcuts ----------
    public function get(string $pattern, mixed $handler, ?string $name = null): self
    {
        return $this->addRoute(['GET'], $pattern, $handler, $name);
    }

    public function post(string $pattern, mixed $handler, ?string $name = null): self
    {
        return $this->addRoute(['POST'], $pattern, $handler, $name);
    }

    public function put(string $pattern, mixed $handler, ?string $name = null): self
    {
        return $this->addRoute(['PUT'], $pattern, $handler, $name);
    }

    public function delete(string $pattern, mixed $handler, ?string $name = null): self
    {
        return $this->addRoute(['DELETE'], $pattern, $handler, $name);
    }

    public function any(string $pattern, mixed $handler, ?string $name = null): self
    {
        return $this->addRoute(['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'], $pattern, $handler, $name);
    }

    public function ajax(string $pattern, mixed $handler, ?string $name = null): self
    {
        return $this->addRoute(['GET', 'POST'], $pattern, $handler, $name, ['ajax_only' => true]);
    }

    public function traditional(string $pattern, mixed $handler, ?string $name = null): self
    {
        return $this->addRoute(['GET', 'POST'], $pattern, $handler, $name, ['no_ajax' => true]);
    }

    // ---------- Group & Middleware ----------
    public function group(array $attributes, callable $callback): self
    {
        $this->groupStack[] = $attributes;
        $callback($this);
        array_pop($this->groupStack);
        return $this;
    }

    public function middleware(string $middlewareClass): self
    {
        $this->middlewareDispatcher->addGlobalMiddleware(new $middlewareClass());
        return $this;
    }

    // ---------- Rate Limiter ----------
    public function rateLimiter(string $name, int $maxRequests, int $period): self
    {
        $this->rateLimiter->define($name, $maxRequests, $period);
        return $this;
    }

    // ---------- Model Binding ----------
    public function bind(string $paramName, string $modelClass): self
    {
        $lastRoute = $this->collection->all()[array_key_last($this->collection->all())] ?? null;
        if ($lastRoute) {
            $bindings = $lastRoute->bindings;
            $bindings[$paramName] = $modelClass;
            $this->collection->add(new Route(
                $lastRoute->methods, $lastRoute->pattern, $lastRoute->handler,
                $lastRoute->name, $lastRoute->middleware, $lastRoute->cors,
                $lastRoute->rateLimiter, $lastRoute->ajaxOnly, $lastRoute->noAjax,
                $lastRoute->constraints, $bindings
            ));
        }
        return $this;
    }

    // ---------- Dispatch ----------
    public function dispatch(): void
    {
        // Method spoofing for forms
        if ($this->request->getMethod() === 'POST' && $method = $this->request->getPostParam('_method')) {
            $this->request->setMethod(strtoupper($method));
        }

        // CORS preflight handling
        $corsConfig = $this->getCorsConfigForCurrentRequest();
        if ($corsConfig && $this->corsManager->handlePreflight($this->request, $this->response, $corsConfig)) {
            return;
        }

        // Match route using RouteMatcher
        $match = $this->matcher->match($this->request);
        if (!$match) {
            $this->sendNotFound();
            return;
        }

        /** @var Route $route */
        $route = $match['route'];
        $params = $match['params'];

        // Rate limiting
        if ($route->rateLimiter && !$this->rateLimiter->attempt($route->rateLimiter, $this->request)) {
            $this->sendRateLimitExceeded($route->rateLimiter);
            return;
        }

        // Model binding (convert params to models)
        $params = $this->modelBinder->bind($params, $route->bindings);

        // CORS headers for actual request
        if ($route->cors) {
            $this->corsManager->applyHeaders($this->response, $route->cors);
        }

        // Prepare final handler
        $callable = $this->handlerResolver->resolve($route->handler);
        $finalHandler = function (HttpRequest $req, HttpResponse $res, array $params) use ($callable) {
            $result = $callable($req, $res, $params);
            if ($result !== null && !$res->isSent()) {
                $this->formatResponse($result, $route->ajaxOnly);
            }
            return $res;
        };

        // Resolve middleware classes (strings -> objects)
        $routeMiddlewares = array_map(function ($mw) {
            if (is_string($mw)) {
                // You can customize namespace here
                $mwClass = 'Mlangeni\\Machinjiri\\App\\Middleware\\' . $mw;
                if (!class_exists($mwClass)) {
                    throw new MachinjiriException("Middleware class {$mwClass} not found");
                }
                return new $mwClass();
            }
            return $mw;
        }, $route->middleware);

        // Dispatch through middleware pipeline
        $response = $this->middlewareDispatcher->dispatch($this->request, $this->response, $routeMiddlewares, $finalHandler);
        if (!$response->isSent()) {
            $response->send();
        }
    }

    // ---------- URL Generation (Static helpers) ----------
    public static function route(string $name, array $params = []): string
    {
        $router = Container::getInstance()->resolve(Router::class);
        return $router->urlGenerator->toRoute($name, $params);
    }

    public static function absoluteRoute(string $name, array $params = []): string
    {
        $router = Container::getInstance()->resolve(Router::class);
        return $router->urlGenerator->toAbsolute($name, $params);
    }

    // ---------- Internal Helpers ----------
    protected function addRoute(array $methods, string $pattern, mixed $handler, ?string $name, array $options = []): self
    {
        $pattern = $this->applyGroupPrefix($pattern);
        $pattern = rtrim($this->basePath . '/' . ltrim($pattern, '/'), '/') ?: '/';

        $route = new Route(
            methods: $methods,
            pattern: $pattern,
            handler: $handler,
            name: $name,
            middleware: array_merge($this->getGroupMiddleware(), $options['middleware'] ?? []),
            cors: $options['cors'] ?? null,
            rateLimiter: $options['rate_limit'] ?? null,
            ajaxOnly: $options['ajax_only'] ?? false,
            noAjax: $options['no_ajax'] ?? false,
            constraints: $options['where'] ?? [],
            bindings: $options['bindings'] ?? []
        );

        $this->collection->add($route);
        return $this;
    }

    protected function getGroupMiddleware(): array
    {
        $middleware = [];
        foreach ($this->groupStack as $group) {
            if (isset($group['middleware'])) {
                $middleware = array_merge($middleware, (array)$group['middleware']);
            }
        }
        return $middleware;
    }

    protected function applyGroupPrefix(string $pattern): string
    {
        $prefix = '';
        foreach ($this->groupStack as $group) {
            $prefix .= $group['prefix'] ?? '';
        }
        return $prefix . $pattern;
    }

    protected function getCorsConfigForCurrentRequest(): ?array
    {
        foreach ($this->collection->all() as $route) {
            if ($route->cors && in_array('OPTIONS', $route->methods)) {
                return $route->cors;
            }
        }
        return null;
    }

    protected function formatResponse($result, bool $ajaxOnly): void
    {
        if ($this->request->isAjax() || $this->request->expectsJson() || $ajaxOnly) {
            $this->response->setJsonBody(is_array($result) || is_object($result) ? $result : ['data' => $result]);
        } elseif (is_string($result)) {
            $this->response->setBody($result);
        } elseif ($result === null) {
            $this->response->setStatusCode(204);
        } else {
            throw new MachinjiriException('Non-AJAX route must return string or null, or use AJAX route for arrays/objects');
        }
        if (!$this->response->isSent()) {
            $this->response->send();
        }
    }

    protected function sendNotFound(): void
    {
        $this->response->setStatusCode(404);
        if ($this->request->isAjax() || $this->request->expectsJson()) {
            $this->response->setJsonBody(['error' => 'Not Found', 'code' => 404]);
        } else {
            $this->response->setBody($this->loadErrorTemplate(404));
        }
        $this->response->send();
    }

    protected function sendRateLimitExceeded(string $limiterName): void
    {
        $this->response->setStatusCode(429)->setHeader('Retry-After', 60);
        if ($this->request->isAjax() || $this->request->expectsJson()) {
            $this->response->setJsonBody(['error' => 'Rate limit exceeded', 'retry_after' => 60]);
        } else {
            $this->response->setBody($this->loadErrorTemplate(429));
        }
        $this->response->send();
    }

    protected function loadErrorTemplate(int $code): string
    {
        // Use container's storage path if available
        if (Container::instancePresent()) {
            $container = Container::getInstance();
            $templatePath = $container->storage . "errors/{$code}.php";
            if (file_exists($templatePath)) {
                ob_start();
                include $templatePath;
                return ob_get_clean();
            }
        }
        return "<h1>Error {$code}</h1><p>An error occurred.</p>";
    }

    protected function detectBasePath(): string
    {
        if (Container::instancePresent()) {
            $base = Container::getRoutingBase();
            if ($base !== '') return $base;
        }

        $configPath = $this->findConfigFile();
        if ($configPath && file_exists($configPath)) {
            $config = require $configPath;
            if (isset($config['base_path']) && is_string($config['base_path'])) {
                return rtrim($config['base_path'], '/');
            }
        }
        return '';
    }

    protected function findConfigFile(): ?string
    {
        if (Container::instancePresent()) {
            $container = Container::getInstance();
            if (property_exists($container, 'config') && $container->config) {
                $path = $container->config . 'app.php';
                if (file_exists($path)) return $path;
            }
        }
        $possiblePaths = [
            __DIR__ . '/../../config/app.php',
            getcwd() . '/config/app.php',
            $_SERVER['DOCUMENT_ROOT'] . '/../config/app.php',
        ];
        foreach ($possiblePaths as $path) {
            if (file_exists($path)) return $path;
        }
        return null;
    }
}