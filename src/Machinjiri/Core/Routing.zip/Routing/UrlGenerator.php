<?php

namespace Mlangeni\Machinjiri\Core\Routing;

use Mlangeni\Machinjiri\Core\Exceptions\MachinjiriException;

class UrlGenerator
{
    public function __construct(
        protected RouteCollection $collection,
        protected string $basePath = '',
        protected ?string $baseUrl = null
    ) {}

    public function toRoute(string $name, array $params = []): string
    {
        $route = $this->collection->getByName($name);
        if (!$route) {
            throw new MachinjiriException("Route '{$name}' not found");
        }
        $path = $route->pattern;
        foreach ($params as $key => $value) {
            $path = str_replace('{' . $key . '}', urlencode((string)$value), $path);
        }
        return $this->basePath . $path;
    }

    public function toAbsolute(string $name, array $params = []): string
    {
        $base = $this->baseUrl ?? $this->detectBaseUrl();
        return rtrim($base, '/') . $this->toRoute($name, $params);
    }

    protected function detectBaseUrl(): string
    {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        return $protocol . '://' . $host;
    }
}